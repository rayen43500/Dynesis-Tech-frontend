import { NextRequest, NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      name, 
      email, 
      phone, 
      company, 
      requestType = 'quote',
      message,
      invoiceNumber,
      projectDetails,
      subscribeNewsletter = false,
    } = body

    // Validation
    if (!name || !email || !message) {
      return NextResponse.json(
        { error: 'Missing required fields (name, email, message)' },
        { status: 400 }
      )
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email address' },
        { status: 400 }
      )
    }

    // Connect to MongoDB
    const { db } = await connectToDatabase()

    // Insert contact message with new fields
    const result = await db.collection('contacts').insertOne({
      name,
      email,
      phone: phone || '',
      company: company || '',
      requestType,
      message,
      invoiceNumber: invoiceNumber || '',
      projectDetails: projectDetails || '',
      subscribeNewsletter,
      createdAt: new Date(),
      status: 'new',
      ip: request.headers.get('x-forwarded-for') || 'unknown',
    })

    // Subscribe to newsletter if opted in
    if (subscribeNewsletter) {
      await db.collection('newsletter_subscribers').updateOne(
        { email },
        {
          $set: {
            email,
            subscribedAt: new Date(),
            source: 'contact_form',
            status: 'active',
          },
        },
        { upsert: true }
      )
    }

    return NextResponse.json(
      { 
        success: true, 
        id: result.insertedId,
        message: 'Your message has been received. We will get back to you soon.' 
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('[v0] Contact API error:', error)
    return NextResponse.json(
      { error: 'Failed to process contact form' },
      { status: 500 }
    )
  }
}
