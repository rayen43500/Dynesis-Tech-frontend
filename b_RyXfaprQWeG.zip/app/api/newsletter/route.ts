import { NextRequest, NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email } = body

    // Validation
    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      )
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Invalid email address' },
        { status: 400 }
      )
    }

    // Connect to MongoDB
    const { db } = await connectToDatabase()

    // Check if already active subscriber
    const existingSubscriber = await db.collection('newsletter_subscribers').findOne({ email })
    if (existingSubscriber && existingSubscriber.status === 'active') {
      return NextResponse.json(
        { error: 'Email already subscribed' },
        { status: 400 }
      )
    }

    // Insert or reactivate subscriber
    const result = await db.collection('newsletter_subscribers').updateOne(
      { email },
      {
        $set: {
          email,
          subscribedAt: new Date(),
          source: 'newsletter_form',
          status: 'active',
        },
      },
      { upsert: true }
    )

    return NextResponse.json(
      { 
        success: true, 
        id: result.insertedId,
        message: 'Successfully subscribed to our newsletter!' 
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('[v0] Newsletter API error:', error)
    return NextResponse.json(
      { error: 'Failed to process newsletter subscription' },
      { status: 500 }
    )
  }
}
